# Phonology

Describe the sounds of your language here.