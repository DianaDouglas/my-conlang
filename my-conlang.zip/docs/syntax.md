# Syntax

Describe sentence structure and word order here.