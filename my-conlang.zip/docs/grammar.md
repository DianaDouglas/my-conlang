# Grammar

Explain morphological and grammatical rules here.