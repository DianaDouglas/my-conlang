# Toraviin Velashii Vathil Darethiin

_"The land where the drops fall of the song of the siren."_

**Language Spoken:** Avliraeth  
**Structure:** Mythic region scroll archive, conlang + cultural lorebook.

---

## Folder Guide

- **maps_and_history/**  
  Geographic records, hand-drawn maps, sacred site annotations.

- **politics_and_systems/**  
  Kingdoms, sea-clans, old laws, power structures, oaths.

- **magic_and_species/**  
  Rules of spellcraft, magical ecology, sentient species guides.

- **language_notes/**  
  Grammar, glyphs, lexicon of Avliraeth — the sacred tongue.

- **culture_and_customs/**  
  Traditions, clothing, food, mourning, rites of passage.

- **family_trees/**  
  Noble houses, lineage sigils, interwoven bloodlines.

- **timelines/**  
  Mythic ages, reigns of rulers, recorded storms.

---

Created for the Codex of the Singing Root.