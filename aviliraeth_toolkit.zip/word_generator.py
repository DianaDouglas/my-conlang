import random

consonants = ['k', 't', 'v', 'z', 'r', 's']
vowels = ['a', 'e', 'i', 'o', 'u']
suffixes = ['shii', 'en', 'iin']

def generate_syllable():
    return random.choice(consonants) + random.choice(vowels)

def generate_word(syllables=2, suffix=True):
    word = ''.join(generate_syllable() for _ in range(syllables))
    if suffix and random.random() < 0.5:
        word += random.choice(suffixes)
    return word

if __name__ == "__main__":
    for _ in range(10):
        print(generate_word())