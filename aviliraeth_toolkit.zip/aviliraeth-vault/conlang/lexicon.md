# Avliraeth Lexicon

| Word      | Meaning            | Part of Speech | Notes                              |
|-----------|--------------------|----------------|------------------------------------|
| tora      | land, realm        | noun           | Root for geographic/spatial terms |
| dareth    | drop, tear, rain   | noun           | Used poetically for precious things |
| iinin     | to fall, descend   | verb           | Often used in ritual texts        |
| vathi     | song               | noun           | Sacred or bardic usage            |
| vela      | siren              | noun           | Poetic creature, source of voice  |
| syen      | where (relative)   | particle       | Introduces relative clauses       |
| -shii     | of (possessive)    | suffix         | Used in poetic or sacred names    |