# Avliraeth Grammar Guide

## Word Order
Default is SVO (Subject-Verb-Object), but poetic and spell forms may reorder for emphasis.

## Particles and Suffixes

| Function      | Form     | Example        | Notes                                |
|---------------|----------|----------------|--------------------------------------|
| Possessive    | -shii    | velashii       | Poetic or sacred usage               |
| Relative clause | syen   | syen iinin...  | "Where..."                           |
| Genitive      | -iin/-en | vathiin        | "Of the song"                        |

## Sample Sentence
**Tora syen iinin darethen vathiin velashii**  
"The land where fall the drops of the song of the siren"