
def lookup(word, lexicon):
    for entry in lexicon.get("words", []):
        if entry["word"] == word:
            return entry
    return None

if __name__ == "__main__":
    import json
    with open("words.json", "r") as f:
        lexicon = json.load(f)

    word = input("Enter a word to lookup: ")
    result = lookup(word, lexicon)
    if result:
        print(f"{word} means '{result['meaning']}' ({result['type']})")
    else:
        print("Word not found.")
