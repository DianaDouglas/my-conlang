
# Avliraeth Alphabet

The Avliraeth writing system is a poetic, vertically anchored script inspired by bird movement, sand trails, and wind paths. It is designed to be elegant, dyslexia-friendly, and culturally meaningful.

---

## Design Principles

- **Vertical Stem:** Every glyph is built around a tall, central vertical line — like a perch, a tether, or wind shaft.
- **Branching Detail:** Curves, wings, dots, or hooks distinguish phonemes.
- **Left-to-Right Flow:** Words are read left to right, but each character flows vertically, downward and outward.
- **No Rotational Mirroring:** Avoids b/d/p/q symmetry confusion.
- **Handwritten Aesthetic:** Glyphs are easy to stylize with brush or pen.

---

## Consonants

| Sound | Glyph Idea                      | Description                            |
|-------|----------------------------------|----------------------------------------|
| k     | Stem + left top hook             | Beak shape — sharp and clipped         |
| t     | Double-stem + crossbar           | Spear or pierce                        |
| p     | Stem + down arc                  | Drop or hook                           |
| d     | Stem + tight inward swirl        | Binding thought                        |
| b     | Small loop top + stem            | Rising voice                           |
| s     | Zigzag on stem                   | Serpent, wind                          |
| sh    | Curved stem + dot above          | Whisper force                          |
| z     | Jagged lightning form            | Electric strike                        |
| v     | Wing curl from base              | Vibration, lift                        |
| h     | Tall stem + tick mark            | Breath, hush                           |
| m     | Double-arch base + short stem    | Grounded sound                         |
| n     | Soft arch + stem                 | Forward step                           |
| r     | Stem with outward hook           | Reach, curve                           |
| l     | Slightly leaning stem            | Slide, flow                            |
| y     | Forked tail from base            | Split or divergence                    |
| w     | Broad base + upward arc          | Wave, openness                         |
| q     | Circular mark (sacred glyph)     | Click or magical sigil                 |

---

## Vowels

| Vowel | Shape Idea         | Concept          |
|-------|--------------------|------------------|
| a     | Open circle on stem| Breath, origin   |
| e     | Leaf curl side     | Change, seeing   |
| i     | Flame/dot above    | Eye, focus       |
| o     | Loop + tail        | Whole, eternal   |
| u     | Downward hook      | Rootedness, depth|

> Vowels flow smoothly and are never mirrored — their shapes suggest openness, movement, and intention.

---

## Diacritics & Punctuation

- **Tone Dot:** Small mark above stem
- **Question Feather:** Two short diagonal ticks
- **Sentence Break:** Stack of tiny arcs (like feather quills)
- **Magic Markers:** Star-shaped dots or radial patterns used in spells

---

## Cultural Usage

- Used in trade, magic, and formal texts
- Glyphs are often **written in calligraphic columns** for poetry or rituals
- Some forms are **sung or whistled** in oral tradition

---

*Next: Create glyph sketches or vector art based on these rules.*
