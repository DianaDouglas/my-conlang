
# Avliraeth Number System

The Avliraeth language uses a **base-10 (decimal)** system that reflects cultural, magical, and philosophical ideas. Numbers are phonetically sharp but balanced and elegant, with overlapping meaning in daily speech and sacred texts.

---

## 1. Base System

- **Base:** Decimal (10)
- Used in trade, communication, and spellcraft
- **Zero** holds spiritual and magical significance
- Compounds build logically using root numerals + tens, hundreds, etc.

---

## 2. Core Numerals (0–10)

| Number | Word      | Meaning / Notes                             |
|--------|-----------|---------------------------------------------|
| 0      | **nul**   | “void / nothing / pause” — magical/philosophical |
| 1      | **vi**    | “one / self” — root of “I”                   |
| 2      | **tuan**  | “pair / balance”                            |
| 3      | **shol**  | “triad / arc” — used in myth and naming     |
| 4      | **kareth**| “stability / square”                        |
| 5      | **ven**   | “hand / unity” — shares root with “we”      |
| 6      | **darek** | “cycle / breath rhythm”                     |
| 7      | **zhal**  | “sacred / prime” — used in rites            |
| 8      | **morin** | “rebirth / loop”                            |
| 9      | **toren** | “horizon / end”                             |
| 10     | **voth**  | “complete / full step”                      |

---

## 3. Teens & Compounds (11–99)

Compound structure:
- `[Tens root]` + `-` + `[Unit root]`
- Example: **tuanvoth-vi** = "twenty-one" (two-tens-one)

| Number | Word              | Structure           |
|--------|-------------------|---------------------|
| 11     | **vothvi**        | ten-one             |
| 12     | **vothtuan**      | ten-two             |
| 20     | **tuanvoth**      | two-tens            |
| 30     | **sholvoth**      | three-tens          |
| 45     | **karethvothven** | four-tens-five      |
| 99     | **torenvothtoren**| nine-tens-nine      |

---

## 4. Hundreds & Thousands

| Value     | Word        | Structure                         |
|-----------|-------------|-----------------------------------|
| 100       | **vireth**  | vi + reth (hundred)               |
| 200       | **tuanreth**| tuan + reth                       |
| 1,000     | **vimaren** | vi + maren (thousand)             |
| 10,000    | **vothmaren**| voth + maren                      |

> **Suffixes**:
> - `reth` = hundred
> - `maren` = thousand

---

## 5. Magical & Sacred Use

- **7 (zhal):** Sacred in spellcraft, often repeated in invocations
- **0 (nul):** Not spoken aloud in rituals; symbol represents *void*
- **3 (shol):** Used in naming systems, prophecies ("Threefold Name")

---

## 6. Future Expansion

- **Glyph System:** Coming soon — visual symbols for each root
- **Counting Terms for Time / Trade:** (e.g., “cycle,” “weight,” “coin”) TBD
- **Ordinal Numbers:** (e.g., "first", "second") to be defined

---

*Numbers are deeply rooted in Avliraeth's worldview: cycles, sacred geometry, and language itself. Extend as your world and grammar evolve.*
